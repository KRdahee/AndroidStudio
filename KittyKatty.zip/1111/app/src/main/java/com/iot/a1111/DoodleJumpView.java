package com.iot.a1111;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.Random;

class PlatformPosition {
    int x, y;
}

public class DoodleJumpView extends SurfaceView implements Runnable {
    private final int WIDTH = 720;
    private final int HEIGHT = 1000;
    private final int PLATFORM_COUNT = 10;

    private boolean isRunning;
    private Thread thread;

    private Bitmap background, platform, doodle;
    private PlatformPosition[] platformsPosition;

    private int x = 100, y = 100, h = 150;
    private float dy = 0;
    private boolean right, left;

    private SurfaceHolder holder;
    private Canvas canvas;
    private Paint paint;

    public DoodleJumpView(Context context) {
        super(context);
        holder = getHolder();
        paint = new Paint();
        loadImages();
        initializePlatforms();
    }

    private void loadImages() {
        background = BitmapFactory.decodeResource(getResources(), R.drawable.background);
        platform = BitmapFactory.decodeResource(getResources(), R.drawable.platform);
        doodle = BitmapFactory.decodeResource(getResources(), R.drawable.doodle);
    }

    private void initializePlatforms() {
        platformsPosition = new PlatformPosition[PLATFORM_COUNT];
        Random random = new Random();
        for (int i = 0; i < PLATFORM_COUNT; i++) {
            platformsPosition[i] = new PlatformPosition();
            platformsPosition[i].x = random.nextInt(WIDTH);
            platformsPosition[i].y = random.nextInt(HEIGHT);
        }
    }

    @Override
    public void run() {
        while (isRunning) {
            update();
            draw();
            try {
                Thread.sleep(1000 / 60); // 60 FPS
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    private void update() {
        // 이동 속도를 조정합니다.
        int moveSpeed = 5; // 이동 속도를 더 빠르게 설정합니다.

        if (right) {
            x += moveSpeed;
        } else if (left) {
            x -= moveSpeed;
        }

        dy += 0.2;  // 중력에 의해 점프 속도가 계속 증가합니다.
        y += dy;

        if (y > HEIGHT - 30) { // 만약 y가 화면 아래로 내려간다면
            dy = -15; // 점프 힘을 더 높입니다
        }

        if (y < h) {
            for (int i = 0; i < PLATFORM_COUNT; i++) {
                y = h;
                platformsPosition[i].y = platformsPosition[i].y - (int) dy;
                if (platformsPosition[i].y > HEIGHT) {
                    platformsPosition[i].y = 0;
                    platformsPosition[i].x = new Random().nextInt(WIDTH);
                }
            }
        }

        for (int i = 0; i < PLATFORM_COUNT; i++) {
            if ((x + 50 > platformsPosition[i].x) &&
                    (x + 20 < platformsPosition[i].x + platform.getWidth()) &&
                    (y + 70 > platformsPosition[i].y) &&
                    (y + 70 < platformsPosition[i].y + platform.getHeight()) &&
                    (dy > 0)) {
                dy = -15; // 점프 힘을 더 높입니다
            }
        }
    }

    private void draw() {
        if (holder.getSurface().isValid()) {
            canvas = holder.lockCanvas();
            canvas.drawBitmap(background, 0, 0, paint);
            canvas.drawBitmap(doodle, x, y, paint);
            for (int i = 0; i < PLATFORM_COUNT; i++) {
                canvas.drawBitmap(platform, platformsPosition[i].x, platformsPosition[i].y, paint);
            }
            holder.unlockCanvasAndPost(canvas);
        }
    }

    public void pause() {
        isRunning = false;
        while (true) {
            try {
                thread.join();
                break;
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    public void resume() {
        isRunning = true;
        thread = new Thread(this);
        thread.start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            if (event.getX() > getWidth() / 2) {
                right = true;
                left = false;
            } else {
                left = true;
                right = false;
            }
        } else if (event.getAction() == MotionEvent.ACTION_UP) {
            right = false;
            left = false;
        }
        return true;
    }
}
