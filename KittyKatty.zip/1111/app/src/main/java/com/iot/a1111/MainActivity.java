package com.iot.a1111;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private int affection = 20;
    private int money = 0;
    private TextView affectionTextView;
    private TextView timeTextView;
    private Handler handler = new Handler();
    private Runnable updateTimeRunnable;
    private long startTime = System.currentTimeMillis();
    private Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        affectionTextView = findViewById(R.id.affectionTextView);
        timeTextView = findViewById(R.id.timeTextView);

        Button button3 = findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int change = random.nextInt(3) - 1; // -1 to +1
                updateAffection(change);
            }
        });

        Button button4 = findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MiniGameActivity.class);
                startActivity(intent);
            }
        });

        Button button5 = findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int change = random.nextInt(4) - 1; // -2 to +2
                updateAffection(change);
            }
        });

        startTimer();
    }

    private void updateAffection(int change) {
        affection += change;
        affectionTextView.setText("호감도: " + affection);
    }

    private void startTimer() {
        updateTimeRunnable = new Runnable() {
            @Override
            public void run() {
                long elapsedTime = System.currentTimeMillis() - startTime;
                long seconds = (elapsedTime / 1000) % 60;
                long minutes = (elapsedTime / (1000 * 60)) % 60;

                timeTextView.setText(String.format("시간: %02d:%02d", minutes, seconds));

                // Update money every second
                money += 10;
                // Update UI if needed (e.g., display money somewhere)

                handler.postDelayed(this, 1000);
            }
        };

        handler.post(updateTimeRunnable);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(updateTimeRunnable);
    }
}
